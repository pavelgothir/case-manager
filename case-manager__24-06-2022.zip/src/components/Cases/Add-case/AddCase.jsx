import React from "react";

const AddCase = ()=>{
    return(
        <div className="add__case">
            
        </div>
    )
}