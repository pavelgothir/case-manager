import React from "react";
import s from "./Cases.module.css";

const Cases = ()=>{
    return (
        <div className={s.cases}>
            Cases
        </div>
    );
}
export default Cases;