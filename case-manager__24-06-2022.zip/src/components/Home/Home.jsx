import React from "react";
import s from "./Home.module.css";
const Home = ()=>{
    return(
        <div className={s.home}>
           <p>
            kkkkk
           </p>
        </div>
    )
}
export default Home;