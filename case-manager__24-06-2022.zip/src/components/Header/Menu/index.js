

const Func = ()=>{
    return console.log("hello")
}
export default Func;